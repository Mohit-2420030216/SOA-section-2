package result__management__portal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

final class DatabaseConnection {

    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/srms";
    private static String configuredUsername;
    private static char[] configuredPassword;

    private DatabaseConnection() {
    }

    static Connection getConnection() throws SQLException {
        String username = System.getenv("SRMS_DB_USER");
        String password = System.getenv("SRMS_DB_PASSWORD");
        String url = System.getenv("SRMS_DB_URL");
        boolean prompted = username == null || username.isBlank() || password == null;

        if (prompted && configuredUsername != null) {
            username = configuredUsername;
            password = new String(configuredPassword);
        } else if (prompted) {
            JTextField usernameField = new JTextField(
                    username == null || username.isBlank() ? "root" : username);
            JPasswordField passwordField = new JPasswordField();
            if (password != null) {
                passwordField.setText(password);
            }
            Object[] fields = {
                "MySQL username:", usernameField,
                "MySQL password:", passwordField
            };
            int choice = JOptionPane.showConfirmDialog(
                    null,
                    fields,
                    "MySQL Database Login",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
            if (choice != JOptionPane.OK_OPTION) {
                throw new SQLException("MySQL login was cancelled.");
            }
            username = usernameField.getText().trim();
            password = new String(passwordField.getPassword());
        }

        Connection connection = DriverManager.getConnection(
                url == null || url.isBlank() ? DEFAULT_URL : url,
                username,
                password);
        if (prompted && configuredUsername == null) {
            configuredUsername = username;
            configuredPassword = password.toCharArray();
        }
        return connection;
    }
}
