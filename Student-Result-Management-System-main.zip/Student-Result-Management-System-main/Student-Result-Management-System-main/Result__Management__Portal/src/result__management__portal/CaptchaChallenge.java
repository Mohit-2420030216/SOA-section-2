package result__management__portal;

import java.security.SecureRandom;

final class CaptchaChallenge {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final char[] CHARACTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();

    private String answer;

    String refresh() {
        StringBuilder code = new StringBuilder(5);
        for (int i = 0; i < 5; i++) {
            code.append(CHARACTERS[RANDOM.nextInt(CHARACTERS.length)]);
        }
        answer = code.toString();
        return "CAPTCHA: " + answer;
    }

    boolean matches(String response) {
        return response != null && answer.equalsIgnoreCase(response.trim());
    }
}
